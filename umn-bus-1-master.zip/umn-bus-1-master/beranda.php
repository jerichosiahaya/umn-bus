<?php
require 'components/header.php';
require 'components/seatConfig.php';
?>

<body>
    <center>
        <h1>SELAMAT DATANG</h1>
        <p>
            <input type="submit" value="Pesan Tiket" onclick="location.href='pesantiket.php';">
            <input type="submit" value="Lihat Tiket" onclick="location.href='lihattiket.php';">
            <input type="submit" value="Batalkan Tiket" onclick="location.href='batalkantiket.php';">
            <input type="submit" value="Jadwal Bis Mingguan" onclick="location.href='jadwalbis.php';">
            <br>
            <h4>* * *</h4>
            <input type="submit" value="Profil">
            <input type="submit" value="Terms & Condition">
            <input type="submit" value="Pengumuman">
            <p>
                <input type="submit" value="Keluar" onclick="location.href='keluar.php';">
    </center>

    </html>