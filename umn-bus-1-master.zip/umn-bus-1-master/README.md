# U-Bus
[![License](http://img.shields.io/:license-mit-blue.svg)](http://doge.mit-license.org)

![Universitas Multimedia Nusantara](https://cdns.klimg.com/merdeka.com/i/w/news/2019/09/19/1110741/670x335/umn-tawarkan-beasiswa-sejumlah-program-studi-khusus-minat.jpg)

## Fitur
- Login (sesuai NIM/ID)
- Memesan tiket
- Melihat tiket
- Membatalkan tiket

## Instalasi
- Download semua file
- Taruh di htdocs XAMPP
- Buat database dengan nama "u-bus" di MySQL Server
- Import SQL File dari folder database (gunakan yang u-bus)
